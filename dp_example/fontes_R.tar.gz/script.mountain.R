source("kbsf.experiments.R")
mountain.exp.lspi.kbsf("./kbsf/mountain/exp/mountain", sizes=c(1600,1800), num.archs=100, use.c.code=FALSE)
